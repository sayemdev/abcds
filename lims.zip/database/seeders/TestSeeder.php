<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Test;
use App\Models\Category;

class TestSeeder extends Seeder
{
    public function run()
    {
        // Create some categories first
        $categories = Category::factory()->count(5)->create();

        // Create parent tests
        $parentTests = Test::factory()->count(5)->create([
            'parent_id' => null,
            'separated' => false,
        ]);

        // Create child tests that are separated
        foreach ($parentTests as $parentTest) {
            Test::factory()->count(3)->create([
                'parent_id' => $parentTest->id,
                'separated' => false,
                'title' => false,
            ]);
        }

        // Create child tests that are not separated
        foreach ($parentTests as $parentTest) {
            Test::factory()->count(2)->create([
                'parent_id' => $parentTest->id,
                'separated' => false,
            ]);
        }

        // Create some tests that are not parent but separated
        Test::factory()->count(5)->create([
            'parent_id' => null,
            'separated' => true,
            'title' => false,
        ]);
    }
}
