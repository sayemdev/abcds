<?php

namespace Database\Factories;

use App\Models\Test;
use App\Models\Category;
use Illuminate\Database\Eloquent\Factories\Factory;

class TestFactory extends Factory
{
    protected $model = Test::class;

    public function definition()
    {
        return [
            'parent_id' => null,
            'name' => $this->faker->word,
            'shortcut' => $this->faker->word,
            'sample_type' => $this->faker->word,
            'unit' => $this->faker->word,
            'reference_range' => $this->faker->word,
            'type' => $this->faker->word,
            'separated' => $this->faker->boolean,
            'price' => $this->faker->randomFloat(2, 10, 100),
            'status' => $this->faker->boolean,
            'title' => $this->faker->boolean,
            'precautions' => $this->faker->paragraph,
            'category_id' => Category::factory(),
        ];
    }
}
