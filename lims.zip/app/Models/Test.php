<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Test extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'parent_id',
        'name',
        'shortcut',
        'sample_type',
        'unit',
        'reference_range',
        'type',
        'separated',
        'price',
        'status',
        'title',
        'precautions',
        'category_id',
    ];

    public function parent()
    {
        return $this->belongsTo(Test::class, 'parent_id');
    }

    public function children()
    {
        return $this->hasMany(Test::class, 'parent_id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function isTest()
    {
        return (is_null($this->parent_id)  && !$this->title) || ($this->separated && !is_null($this->parent_id) && !$this->title);
    }
}
