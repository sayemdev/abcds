<?php

namespace App\Http\Controllers;

use App\Models\Test;
use Illuminate\Http\Request;
use App\Http\Requests\StoreTestRequest;
use App\Http\Requests\UpdateTestRequest;

class TestController extends Controller
{
    public function index()
    {
        // Fetch only the entries considered as tests
        $tests = Test::all()->filter(function ($test) {
            return $test->isTest();
        })->values()->toArray();
        
        return response()->json($tests);
    }

    public function store(StoreTestRequest $request)
    {
        $test = Test::create($request->validated());
        return response()->json($test, 201);
    }

    public function show(Test $test)
    {
        if (!$test->isTest()) {
            return response()->json(['message' => 'Not a valid test'], 404);
        }

        return response()->json($test);
    }

    public function update(UpdateTestRequest $request, Test $test)
    {
        $test->update($request->validated());
        return response()->json($test);
    }

    public function destroy(Test $test)
    {
        $test->delete();
        return response()->noContent();
    }
}
