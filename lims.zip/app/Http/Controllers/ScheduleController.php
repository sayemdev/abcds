<?php
namespace App\Http\Controllers;

use App\Models\Schedule;
use App\Models\Employee;
use App\Models\Designation;
use App\Models\Shift;
use Carbon\Carbon;
use Carbon\Exceptions\InvalidFormatException;
use Illuminate\Support\Facades\Log;
use App\Http\Requests\StoreScheduleRequest;
use App\Http\Requests\UpdateScheduleRequest;

class ScheduleController extends Controller
{
    public function index()
    {
        // Get employees with no end date
        $employees = Employee::where("end_date", null)->get();
        
        // Get the current date
        $currentDate = Carbon::today();
        
        // Calculate the date 7 days from now
        $endDate = $currentDate->copy()->addDays(7);
    
        // Iterate through each employee
        foreach ($employees as $employee) {
            // Get schedules for the current employee within the date range
            $schedules = Schedule::whereBetween('date', [$currentDate, $endDate])->get();
    
            // Define an array to hold the dates of available shifts
            $shiftDates = [];
    
            // Iterate through each schedule for the employee
            foreach ($schedules as $schedule) {
                // Get the date of the schedule
                $scheduleDate = Carbon::createFromFormat('Y-m-d', $schedule->date)->toDateString();
    
                // Add the date to the array if it's not already present
                if (!in_array($scheduleDate, $shiftDates)) {
                    $shiftDates[] = $scheduleDate;
                }
    
                // Retrieve and format shift timings
                $schedule->shift = Shift::find($schedule->shift_id);
                $start = trim($schedule->shift->start);
                $end = trim($schedule->shift->end);
                $formattedStart = Carbon::createFromFormat('H:i:s', $start)->format('g:i A');
                $formattedEnd = Carbon::createFromFormat('H:i:s', $end)->format('g:i A');
                $schedule->shift->time = $formattedStart . " - " . $formattedEnd;
            }
    
            // Add the shift dates array to the employee object
            $employee->shift_dates = $shiftDates;
            $employee->schedules = $schedules;
        }
    
        // Return the response as JSON
        return response()->json($employees);
    }

    public function store(StoreScheduleRequest $request)
    {
        // Get validated data from the request
        $validatedData = $request->validated();
    
        // Check if there's an existing schedule for the employee on the specified date
        $existingSchedule = Schedule::where('employee', $validatedData['employee'])
                                    ->where('date', $validatedData['date'])
                                    ->first();
    
        // If an existing schedule is found, update it
        if ($existingSchedule) {
            $existingSchedule->update($validatedData);
            return response()->json($existingSchedule, 200);
        }
    
        // If no existing schedule is found, create a new one
        $schedule = Schedule::create($validatedData);
        return response()->json($schedule, 201);
    }
    

    public function show(Schedule $schedule)
    {
        $schedule->load('shift'); // Eager load the shift relationship

        // Retrieve employee details based on IDs stored in the employees field
        $employeeIds = $schedule->employees;
        $employees = Employee::whereIn('id', $employeeIds)->get();

        // foreach($employees as $employee){
        //     $employee->designation=Designation::where('id',$employee->designation)->first()->name;
        // }

        // Optionally, you can modify the employees array to include additional details
        $employeesFormatted = $employees->map(function ($employee) {
            return [
                'id' => $employee->id,
                'name' => $employee->name,
                'designation_id' => $employee->designation,
                'designation' => Designation::where('id', $employee->designation)->first()->name
            ];
        });

        return response()->json([
            'id' => $schedule->id,
            'employees' => $employeesFormatted,
            'date' => $schedule->shift_id,
            'shift_id' => $schedule->date,
            'shift_details' => $schedule->shift, // Include details of the shift
            'accept_extra_hours' => $schedule->accept_extra_hours,
            'status' => $schedule->status,
            'created_at' => $schedule->created_at,
            'updated_at' => $schedule->updated_at,
        ]);
    }

    public function update(UpdateScheduleRequest $request, Schedule $schedule)
    {
        $schedule->update($request->validated());
        return response()->json($schedule, 200);
    }

    public function destroy(Schedule $schedule)
    {
        $schedule->delete();
        return response()->json(null, 204);
    }
}
